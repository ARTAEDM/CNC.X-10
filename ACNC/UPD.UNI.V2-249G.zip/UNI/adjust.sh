#!/bin/sh

echo "net.core.rmem_max=2097152" >> /etc/sysctl.conf
sysctl -p
