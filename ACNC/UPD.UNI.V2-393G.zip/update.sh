#!/bin/sh 

if [ "$(uname -n)" == "arta-cnc" ]; then
 # ARTAOS
 XTERM="xterm"
 PIDOF="pidof -x"
 TRG="/media/sda1"
 EX=".AOS"
else
 # TC7
 XTERM="lxterminal"
 PIDOF="pidof"
 TRG="/mnt/sda1"
 EX=".TC7"
fi

# test for runing main cnc script 
if [ -n "$($PIDOF runcnc)" ]; then 
 echo 'exit' 
 #kill main cnc script 
 sudo kill $($PIDOF runcnc) 
 #fork 
 $XTERM -e $0 $@ & 
 exit 0; 
fi 

echo "stage:2" 

# wait for ACNC finish 
while [ -n "$($PIDOF ACNC)" ] 
do 
 sleep 1 
 echo "wait for CLOSING ACNC" 
done 

echo "ACNC CLOSED" 

if [ -e  /tmp/pd ]; then 
 echo "stop on power down" 
 # skip updating 
 echo -e "Update skipped.\nPower down detected." | xmessage -center -timeout 60 -file - 
 read 
 exit 0; 
fi 

# sysmode 
$TRG/CNC/sysmode rw 

#make reserv copy 
echo "make RESERV copy" 
mkdir $TRG/RESERV 
cd $TRG/RESERV 
tar -czf rsrv$(date +%Y%m%d%H%M)$EX.tar.gz $TRG/CNC 

################## 
#     UPDATE     # 
################## 

# $1 = update path 

# extract arhive
unzip -o $1/upd.zip -d $TRG/CNC/  
# select platform binary 
cp -f $TRG/CNC/ACNC$EX $TRG/CNC/ACNC 
ren()
{
 cp -f $1 $(dirname $1)/$(basename $1 $EX)
}
find $TRG/CNC/CMPL -name "*$EX" | while read file; do ren "$file"; done

# 
sync 

$TRG/CNC/sysmode ro 

echo -e "The system is updated successfully.\nREBOOTING" | xmessage -center -timeout 10 -file - 

#restart CNC 
echo "RESTART CNC" 
cd $TRG/CNC 
./runcnc 
