#!/bin/sh 


TRG="/mnt/sda1" 
DST="/etc/sysconfig/tcedir" 

# DETECT ATYPICAL CASE 
docustom() 
{ 
 echo "You cannot install this update option." 
 echo "Contact support [support@edm.ru]" 

 echo -e "You cannot install this update option.\nContact support: [support@edm.ru]" > /tmp/upd.msg 
 lxterminal -e "xmessage -center -timeout 60 -file /tmp/upd.msg" & 

 exit 0 
} 

ETH=$(grep -c "^sudo ./seteth.sh" $TRG/CNC/runcnc) 
CUR=$(grep -c ".cur.ini" $TRG/CNC/CFG/cur.cfg) 

if [[ "$ETH" -gt 0 ]];  
then 
 docustom 
fi 

if [[ "$CUR" -eq 0 ]]; 
then 
 docustom 
fi 

# test for runing main cnc script 
if [ -n "$(pidof runcnc)" ]; then 
 echo 'exit' 
 #kill main cnc script 
 sudo kill $(pidof runcnc) 
 #fork 
 lxterminal -e $0 $@ & 
 #nohup $0 $@ &  
 # and exit 
 exit 0; 
fi 

echo "stage:2" 

# wait for ACNC finish 
while [ -n "$(pidof ACNC)" ] 
do 
 sleep 1 
 echo "wait for CLOSING ACNC" 
done 

echo "ACNC CLOSED" 

if [ -e  /tmp/pd ]; then 
 echo "stop on power down" 
 # skip updating 
 echo -e "Update skipped.\nPower down detected." | xmessage -center -timeout 60 -file - 
 read 
 exit 0; 
fi 

# sysmode 
if [ -f $TRG/CNC/sysmode ]; then 
 $TRG/CNC/sysmode rw 
else 
 cp -f $1/UNI/sysmode $TRG/CNC/sysmode 
fi 

#make reserv copy 
echo "make RESERV copy" 
mkdir $TRG/RESERV 
cd $TRG/RESERV 
tar -czf rsrv$(date +%Y%m%d%H%M).tar.gz $TRG/CNC 

# unrar
echo "load unrar" 
cp -f $1/UNI/unrar.tcz /tmp/unrar.tcz 
sudo -u tc tce-load -i /tmp/unrar.tcz 

# SAMBA
if grep -q "samba.tcz" $DST/onboot.lst; 
then 
  echo "SAMBA OK\n" 
else 
  unrar x -y $1/samba.rar $DST/optional/ 
  cp -f $1/UNI/samba $TRG/CNC/samba 
  echo "samba.tcz" >> $DST/onboot.lst 
fi  

# runcnc+stopcnc
cp -f $1/UNI/runcnc $TRG/CNC/runcnc 
cp -f $1/UNI/stopcnc $TRG/CNC/stopcnc 
cp -f $1/UNI/adjust.sh $TRG/CNC/adjust.sh 


################## 
#     UPDATE     # 
################## 

# $1 = update path 

# extract arhive
unrar x -y $1/upd.rar $TRG/CNC/ 

# 
sync 

$TRG/CNC/sysmode ro 

echo -e "The system is updated successfully.\nREBOOTING" | xmessage -center -timeout 10 -file - 

#restart CNC 
echo "RESTART CNC" 
cd $TRG/CNC 
./runcnc 
