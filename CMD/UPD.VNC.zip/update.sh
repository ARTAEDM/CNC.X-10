#!/bin/sh 


TRG="/mnt/sda1" 
DST="/etc/sysconfig/tcedir" 

echo "stage:2" 

if [ -e  /tmp/pd ]; then 
 echo "stop on power down" 
 # skip updating 
 echo -e "Update skipped.\nPower down detected." | xmessage -center -timeout 60 -file - 
 read 
 exit 0; 
fi 

# sysmode 
$TRG/CNC/sysmode rw 

# VNC
cp -f $1/VNC/x11vnc.tcz $DST/optional/x11vnc.tcz 
cp -f $1/VNC/rx11vnc $TRG/CNC/rx11vnc 
cp -f $1/VNC/.jwmrc-keys /home/tc/.jwmrc-keys 
chmod 666 /home/tc/.jwmrc-keys 
sudo -u tc filetool.sh -b 

sync 

$TRG/CNC/sysmode ro 

jwm -restart 

echo "RESTART CNC" 
