-- активируем службу LVNC

os.execute('/mnt/sda1/CNC/lvnc off')