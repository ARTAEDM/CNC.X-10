#!/bin/sh 

if [ $2 != 1 ]; then 
 # ��������� � ��������� ������
 lxterminal -e $0 $1 1 & 
 exit 0; 
fi 


TRG="/mnt/sda1" 

#get status 

sudo fsck.fat -a -w -v /dev/sda1 > /tmp/res1.txt 
sudo fsck.fat -a -w -v /dev/sda2 > /tmp/res2.txt 
sudo mount > /tmp/res3.txt 
sudo ls -l -R /mnt/sda1/tce* > /tmp/res4.txt 
sudo ifconfig > /tmp/res5.txt 
sudo dmesg | grep "\bBIOS\s" > /tmp/res6.txt 

cd $1 
tar -czf save$(date +%Y%m%d%H%M).tar.gz $TRG/CNC /tmp/res?.txt 

sudo umount /dev/sdb? 
xmessage -center -timeout 3 "TASK: Complite" 