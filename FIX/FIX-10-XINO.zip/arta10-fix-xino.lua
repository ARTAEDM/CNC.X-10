-- обновление ядра счпу

local dsPath = '/media/sda1/CNC/'
local upPath = '/media/sdb1/'
--local dsPath = '/media/sda1/CNC/'
--local upPath = './'

local function execute(val)
 local openPop = assert(io.popen(val)) --, 'r'
 local output = openPop:read('*a')
 openPop:close()
 return output
end

local function sleep(n)
 execute('sleep '..tostring(n))
end

local function rw()
 execute('/CNC/sysmode rw')
 sleep(1)
end
local function ro()
 execute('/CNC/sysmode ro')
 sleep(1)
end



local function backup()
 execute('mv -f ' .. dsPath .. 'HCNC '.. dsPath .. 'HCNC.B')
end

local function restore()
 execute('mv -f ' .. dsPath .. 'HCNC.B '.. dsPath .. 'HCNC')
end

local function install()
 execute('mkdir -p /tmp/core')
 execute('unzip -o ' .. upPath .. 'fix10-xino.zip -d /tmp/core/')
 execute('cp -fr /tmp/core/. '.. dsPath)
end


-- полный комплект
rw()
backup()
install()

execute('sudo mount -o remount,notrunc_xino /')

if execute('if [ -f '.. dsPath .. 'HCNC ' .. ' ]; then  echo "1"; else echo "0"; fi'):sub(1,1) ~= '1' then 
 restore() 
end

ro()
